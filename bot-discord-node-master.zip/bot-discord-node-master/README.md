# Bot criando usando Discord.js

Este bot foi desenvolvido em uma série de vídeo-aulas no Youtube, que podem ser encontradas [aqui](https://www.youtube.com/playlist?list=PLekCEh3NxQrJeaV4Wka-tX0vs3Jrm5XQK)